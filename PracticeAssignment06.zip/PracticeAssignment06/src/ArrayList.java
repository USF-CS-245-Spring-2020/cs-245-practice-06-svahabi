public class ArrayList<T> implements List<T> {
    protected T[] arr;
    protected int size;
    public ArrayList(){
       arr = (T[]) new Object[10];
        size = 0;
    }

    @Override
    public void add(int pos, T data) throws IndexOutOfBoundsException{
        if(pos < 0 || pos > size)
            throw new ArrayIndexOutOfBoundsException("Invalid index.");
        if(size == arr.length){
            double_array();
        }
        size++;
        arr[pos] = data;
    }
    @Override
    public void add(T data){
        if(size == arr.length){
            double_array();
        }
        arr[size++] = data;

    }
    @Override
    public T get(int pos) throws ArrayIndexOutOfBoundsException{
        if(pos < 0 || pos >= size)
            throw new ArrayIndexOutOfBoundsException("Invalid index.");
        return arr[pos];
    }
    @Override
    public T remove(int pos){
        T temp = arr[pos];
        for(int i = pos; i < size; i++){
            arr[i] = arr[i+1];
            --size;
        }
        return temp;
    }

    public void double_array() {
        T[] new_a = (T[]) new Object[arr.length * 2];
        for (int i = 0; i < arr.length; i++) {
            new_a[i] = arr[i];

        }
        arr = new_a;

    }

    @Override
    public int size(){
        return size;
    }


}
